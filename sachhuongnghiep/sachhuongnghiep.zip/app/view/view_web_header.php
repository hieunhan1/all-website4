<div id="header">
    <div id="logo">
        <a href="/"><img src="themes/website/img/logo.png" alt="<?php echo $this->_config['sitename'];?>" /></a>
    </div>
    
    <div class="header_item all_icon" style="background-position:0px -190px">
    	10.000 tựa sách <span>Cập nhật mỗi ngày</span>
    </div>
    <div class="header_item all_icon" style="background-position:0px -140px">
    	Miễn phí giao hàng <span>Tận nơi toàn Quốc</span>
    </div>
    <div class="header_item all_icon" style="background-position:25px -90px">
    	Hotline <span><?php echo $this->_config['hotline'];?></span>
    </div>
</div>
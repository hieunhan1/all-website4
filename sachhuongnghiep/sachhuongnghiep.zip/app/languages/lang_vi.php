<?php
define('CONS_LOGIN','Đăng nhập');
define('CONS_LOGOUT','Thoát');
define('CONS_USERNAME','Tên đăng nhập');
define('CONS_PASSWORD','Mật khẩu');
define('CONS_REMEMBER','Ghi nhớ');
define('CONS_REGISTER','Đăng ký');
define('CONS_FORGOT_PASSWORD','Quên mật khẩu');
define('CONS_CHANGE_PASSWORD','Đổi mật khẩu');

define('CONS_OTHER_POST','Bài viết khác');
define('CONS_OTHER_PRODUCT','Sản phẩm khác');

define('CONS_CONTACT_INFO', 'Thông tin liên hệ');
define('CONS_CONTACT_NAME', 'Họ &amp; tên');
define('CONS_CONTACT_PHONE', 'Điện thoại');
define('CONS_CONTACT_ADDRESS', 'Địa chỉ');
define('CONS_CONTACT_MESSAGE', 'Nội dung');
define('CONS_CONTACT_SEND', 'GỬI LIÊN HỆ');

define('CONS_HOME_CALL_NOW', 'Gọi cho chúng tôi');
define('CONS_HOME_PARTNER', 'Đối tác liên kết');
define('CONS_HEADER_INPUT_CODE', 'Nhập mã');
define('CONS_ERROR_NAME', 'Nhập họ tên');
define('CONS_ERROR_PHONE', 'Điện thoại chưa đúng');
define('CONS_ERROR_ADDRESS', 'Nhập địa chỉ');
define('CONS_ERROR_EMAIL', 'Email chưa đúng');
define('CONS_ERROR_MESSAGE', 'Nội dung phải hơn 10 ký tự');
?>
<?php
/*
 * Pusher chat
 * facebook like chat jQuery plugin using Pusher API 
 * version: 1.0   
 * Author & support : zied.hosni.mail@gmail.com 
 * © 2012 html5-ninja.com
 * for more info please visit http://html5-ninja.com
 * 
 */

// create an account on http://pusher.com/ to obtain API access
$key = 'GET YOUR KEY FROM http://pusher.com';
$secret = 'GET YOUR KEY FROM http://pusher.com';
$app_id = 'GET YOUR KEY FROM http://pusher.com';
?>
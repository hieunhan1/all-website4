﻿/// <reference path="jquery.chatjs.adapter.servertypes.ts"/>


//# sourceMappingURL=jquery.chatjs.adapter.js.map

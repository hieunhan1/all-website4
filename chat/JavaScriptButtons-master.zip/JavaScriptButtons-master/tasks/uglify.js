'use strict';


module.exports = function uglify(grunt) {

    return {
        all: {
            files: {
                'dist/button.js': ['dist/button.js']
            }
        }
    };

};

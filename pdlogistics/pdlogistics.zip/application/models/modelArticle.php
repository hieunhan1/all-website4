<?php
class modelArticle extends modelDB{
	
}
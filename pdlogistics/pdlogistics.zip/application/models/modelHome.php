<?php
class modelHome extends modelDB{
	
}
?>
<?php
class modelProduct extends modelDB{
	
}
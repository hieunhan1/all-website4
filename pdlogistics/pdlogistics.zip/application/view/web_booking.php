<div id="frmBooking">
    <h4>Quick Booking</h4>
    <table width="100%" border="0" cellpadding="0" cellspacing="10">
    	<tr>
        	<td align="right">Name</td>
        	<td><input type="text" name="name" class="txtBooking" /></td>
        </tr>
    	<tr>
        	<td align="right">Phone</td>
        	<td><input type="text" name="phone" class="txtBooking" /></td>
        </tr>
    	<tr>
        	<td align="right">Address</td>
        	<td><input type="text" name="address" class="txtBooking" /></td>
        </tr>
    	<tr>
        	<td align="right" valign="top">Message</td>
        	<td><textarea name="message" class="txtaBooking"></textarea></td>
        </tr>
    	<tr>
        	<td align="right">&nbsp;</td>
        	<td><input type="button" name="btnBooking" value="Booking" class="btnBooking" /></td>
        </tr>
    </table>
</div>
<div class="container">
	<?php
    include_once('web_slider.php');
    include_once('web_booking.php');
	
	$dataMenu = $c->_model->_listParentMenu($currentMenu['id']);
    ?>
	<div class="clear20"></div>
	<div id="home">
        <div id="homeAbout" class="viewpost">
            <?php
            $data = $c->_model->_listDetailMenu('web_article', $currentMenu['id'], 1);
            echo '<h3 style="color:#f0484e; font-size:140%">'.$data[0]['name'].'</h3>
            <p>'.$data[0]['content'].'</p>
            <a href="'.$data[0]['url'].'" style="float:right; text-decoration:underline">Xem thêm</a><br /><br />';
            ?>
        </div>
        <div id="home_news">
            <h3 style="color:#4086AE; font-size:140%; padding-bottom:10px"><?php echo $dataMenu[0]['name'];?></h3>
            <?php
            $limit = 5;
            $data = $c->_model->_listDetailMenu('web_article', $dataMenu[0]['id'], $limit);
            foreach($data as $row){
                echo '<li class="home_news_item allIcon" style="background-position:0px -400px"><a href="'.$row['url'].'" title="'.$row['name'].'">'.$row['name'].'</a></li>';
            }
            ?>
        </div>
        <div class="clear1"></div>
        
        <div id="service_home" class="all_icon_bg bogoc_5px">
            <a href="vi/dich-vu/"><h2>Dịch vụ vận chuyển của PD Logistics</h2></a>
            <div class="service_home_box bogoc_5px">
                <a href="vi/hang-khong/" title="Dịch vụ vận chuyển hàng không Hoàng Hà" class="service_home_title"><h3>Hàng không</h3></a>
                <h4 class="service_home_item allIcon"><a href="vi/dong-vat-song/" title="Vận chuyển động vật sống">Động vật sống</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/hang-hoa-de-hong/" title="Vận chuyển hàng hóa dễ hỏng">Hàng hóa dễ hỏng</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/hang-hoa-chuyen-mon/" title="Vận chuyển hàng hóa chuyên môn">Hàng hóa chuyên môn</a></h4>
             </div>
             <div class="service_home_box bogoc_5px"><a href="vi/duong-bien-1/" title="Dịch vụ vận chuyển đường biển" class="service_home_title"><h3>Đường biển</h3></a>
                <h4 class="service_home_item allIcon"><a href="vi/duong-bien-1/sea-freight-quotation.html" title="Sea freight Quotation">Sea freight Quotation</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/duong-bien-1/fiata.html" title="FIATA">FIATA</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/duong-bien-1/cac-loai-container.html" title="Các loại container">Các loại container</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/duong-bien-1/ma-container.html" title="Mã container">Mã container</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/duong-bien-1/fcl-full-container-load.html" title="FCL - Full Container Load">FCL - Full Container Load</a></h4>
            </div>
            <div class="service_home_box bogoc_5px"><a href="vi/logistics-1/" title="Hoàng Hà Logistics" class="service_home_title"><h3>Logistics</h3></a>
                <h4 class="service_home_item allIcon"><a href="vi/gia-cong-dong-goi/" title="Gia công đóng gói hàng thủy hải sản - Seafood">Gia công, đóng gói</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/dai-ly-bao-hiem/" title="Đại lý bảo hiểm vận chuyển hàng hóa - Insurance">Đại lý bảo hiểm</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/dai-ly-hai-quan/" title="Đại lý hải quan">Đại lý hải quan</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/dich-vu-chung-tu-xuat-nhap-khau/" title="Dịch vụ chứng từ xuất nhập khẩu">Dịch vụ chứng từ xuất nhập khẩu</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/kho-hang/" title="Kho hàng - Warehouse">Kho hàng</a></h4>
           </div>
           <div class="service_home_box bogoc_5px"><a href="vi/chuyen-phat-nhanh/" title="Dịch vụ chuyển phát nhanh - Express" class="service_home_title"><h3>Chuyển phát nhanh</h3></a>
                <h4 class="service_home_item allIcon"><a href="vi/loai-hinh-dich-vu-chuyen-phat-nhanh/" title="Loại hình dịch vụ chuyển phát nhanh">Loại hình chuyển phát nhanh</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/dich-vu-gia-tang/" title="Dịch vụ gia tăng - Chuyển phát nhanh">Dịch vụ gia tăng</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/bang-gia-chuyen-phat-nhanh/" title="Bảng giá chuyển phát nhanh">Bảng giá chuyển phát nhanh</a></h4>
                <h4 class="service_home_item allIcon"><a href="vi/thong-tin-ho-tro-khach-hang/" title="Thông tin hỗ trợ khách hàng">Thông tin hỗ trợ khách hàng</a></h4>
           </div>
           
           <div class="clear20"></div>
        </div>
    
        <div class="clear1"></div>
        
        <div id="home_library">
            <h3 class="home_title"><?php echo $dataMenu[1]['name'];?></h3>
            <div id="photos"><ul>
				<?php
                $data = $c->_model->_listDetailMenu('web_photo', $dataMenu[1]['id'], 6, '`img`', '`order`');
                foreach($data as $row){
                    echo '<li class="img"><a class="fancybox" href="'.$urlImg[5]['url_img'].$row['img'].'" data-fancybox-group="gallery" title="'.$row['name'].'"><img src="'.$urlImg[5]['url_img'].$row['img'].'" alt="'.$row['name'].'" /></a></li>';
                }
                ?>
            </ul></div>
            <div style="clear:both; height:30px;"></div>
            <link rel="stylesheet" type="text/css" href="js/extension/source/jquery.fancybox.css?v=2.1.5" media="screen" />
            <script type="text/javascript" src="js/extension/source/jquery.fancybox.js?v=2.1.5"></script>
            <script type="text/javascript" charset="utf-8"> $(document).ready(function(){ $(".fancybox").fancybox(); }); </script>
        </div>
        
        <div id="home_links">
            <h3 class="home_title"><?php echo $dataMenu[2]['name'];?></h3>
            <?php
            $position = 3;
            $data = $c->_model->_listSliderBanner($lang, $position, $dataMenu[2]['id']);
            foreach($data as $row){
                echo '<li class="home_links_item"><a href="'.$row['url'].'" title="'.$row['name'].'"><img src="'.$urlImg[12]['url_img'].$row['img'].'" alt="'.$row['name'].'" /></a></li>';
            }
            ?>
        </div>
        
        <div id="sale_online_cargo">
            <h3 style="color:#f0484e; font-size:140%">Sale online</h3>
            <div class="sale_online_cargo_item">Trụ sở TpHCM:
                <a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Mr.Liêm</a>
                <a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Ms.Thư</a>
            </div>
            <div class="sale_online_cargo_item">Chi nhánh Hà Nội: <a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Ms.Thư</a><a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Mr.Minh</a>
    </div>
            <div class="sale_online_cargo_item">Chi nhánh Đà Nẵng: <a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Ms.Trân</a><a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Ms.Nhàn</a>
    </div>
            <div class="sale_online_cargo_item">Chi nhánh Cần Thơ: <a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Mr.Nam</a><a href="ymsgr:sendIM?hieu_nhan1"><img src="http://opi.yahoo.com/online?u=hieu_nhan1&amp;m=g&amp;t=0"> Ms.Trinh</a>
    </div>
        </div>
    </div>
    
    <div class="clear30"></div>
</div>
<?php
if($lang==CONS_DEFAULT_LANG) $link=CONS_BASE_URL;
else $link=CONS_BASE_URL.'/?lang='.$lang;
?>
<div id="header">
	<div class="container">
        <a href="" title="Phương Đông Logistics"><img src="themes/website/img/logo_2.png" alt="Phương Đông Logistics" id="logo" /></a>
        <div id="company">
            <h4>CÔNG TY TNHH QUỐC TẾ LOGISTIC</h4>
            <h3>PHƯƠNG ĐÔNG</h3>
        </div>
        <div id="hotline">
            <div id="hotline_icon" class="allIcon" style="background-position:20px -30px">Hotline booking</div>
            <div id="hotline_number">0912.888.747<br />0912.888.750</div>
        </div>
    </div>
</div>
<?php
define('CONS_LOGIN_FAILED','Tên đăng nhập hoặc mật khẩu sai');

define('CONS_MESSAGE_CHANGE_PASS_1',' - Mật khẩu mới và mật khẩu nhắc lại không khớp.<br />');
define('CONS_MESSAGE_CHANGE_PASS_2',' - Mật khẩu mới phải bé hơn 32 ký tự <br />');
define('CONS_MESSAGE_CHANGE_PASS_3',' - Mật khẩu mới phải 6 ký tự trở lên <br />');
define('CONS_MESSAGE_CHANGE_PASS_4',' - Mật khẩu phải chứa ít nhất 1 ký tự <strong>SỐ</strong> <br />');
define('CONS_MESSAGE_CHANGE_PASS_5',' - Mật khẩu phải chứa ít nhất 1 ký tự <strong>THƯỜNG</strong> <br />');
define('CONS_MESSAGE_CHANGE_PASS_6',' - Mật khẩu phải chứa ít nhất 1 ký tự <strong>HOA</strong> <br />');
define('CONS_MESSAGE_CHANGE_PASS_7','Mật khẩu chưa đạt yêu cầu:');
define('CONS_MESSAGE_CHANGE_PASS_8','Mật khẩu cũ không đúng.');
define('CONS_MESSAGE_CHANGE_PASS_9','Đổi mật khẩu thành công.');

define('CONS_BTN_CREATE','Thêm mới');
define('CONS_BTN_UPDATE','Cập nhật');

define('CONS_DATA_ACTION_1','<p class="message">Cập nhật thành công</p>');
define('CONS_DATA_ACTION_2','<p class="error">Lỗi. Vui lòng kiểm tra lại.</p>');
define('CONS_DATA_ACTION_3','<p class="error">Vui lòng nhập dữ liệu</p>');

define('CONS_MESSAGE_RULE_1','<p class="error">Không tồn tại trang này</p>');
define('CONS_MESSAGE_RULE_2','<p class="error">Vui lòng liên hệ người quản trị để cấp quyền.</p>');

?>
<?php
class controlProduct{
	
}
?>
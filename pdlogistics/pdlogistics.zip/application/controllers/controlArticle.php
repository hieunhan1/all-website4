<?php
class controlArticle{
	
}
?>
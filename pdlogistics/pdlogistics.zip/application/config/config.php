<?php
define('CONS_BASE_URL', 'http://localhost/all/pdlogistics');/*domain*/
define('CONS_BASE_DIR', '/all/pdlogistics/');/*upload host tắt CONS này*/
define('CONS_HOST', 'localhost');
define('CONS_USER_DB', 'root');
define('CONS_PASS_DB', '');
define('CONS_NAME_DB', 'pdlogistics');
define('CONS_DEFAULT_LANG', 'vi');

/*SEND MAIL*/
define('CONS_HOST_SMTP_SERVER', 'localhost');
define('CONS_SEND_MAIL_ACCOUNT', 'no-reply@localhost.com');
define('CONS_SEND_MAIL_PASSWORD', 'no-reply#123*');
define('CONS_RECEIVE_MAIL_ACCOUNT', 'hieunhan112@gmail.com');
define('CONS_RECEIVE_MAIL_NAME', 'Admin');

/*CONTROL PAGE*/
define('CONS_PAGE_HOME', 'home');
define('CONS_PAGE_AJAX', 'ajax');
define('CONS_PAGE_ADMIN', 'cp_admin');
define('CONS_WEB_PAGE', 'pages');
define('CONS_WEB_DETAIL', 'details');

/*WEBSITE*/
define('ERROR_NOT_FOUND_CONTROLLER', 'Not found controller');
define('ERROR_NOT_FOUND_FILE', 'Not found file');
define('ERROR_NOT_FOUND_PAGE', 'Not found page');
define('CONS_IMAGE_DEFAULT','themes/website/img/no-image.jpg');

/*ADMIN*/
define('CONS_ADMIN_CSS_IMG', 'themes/admin/img/');
define('CONS_ADMIN_CSS_STYLE', 'themes/admin/admin_default.css');
define('CONS_ADMIN_PER_PAGE', 30);
define('CONS_ADMIN_PASSWORD_DEFAULT', '00112233');
define('CONS_ADMIN_CHANGE_ALIAS', 'Nhấp doubleclick để lấy tên không dấu');
define('CONS_ADMIN_AUTO_URL', 'Nhấp doubleclick để lấy link tự động');
define('CONS_ADMIN_AUTO_TAGS', 'Nhấp doubleclick để lấy keyword tự động');

/*ERROR*/
define('CONS_400','error/400');
define('CONS_404','error/404');
define('CONS_500','error/500');
<?php
define('CONS_NUMBER_LOGIN', 8);
define('CONS_DISABLE_DATE', 60*15);